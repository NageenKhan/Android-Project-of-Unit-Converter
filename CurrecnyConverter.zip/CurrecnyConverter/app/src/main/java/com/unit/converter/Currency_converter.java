package com.unit.converter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class Currency_converter extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    double value1, value2;
    String[] currencyUnits;
    Spinner spin;
    Spinner spin2;
    EditText editText, editText2;
    Button convert_btn;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currency_converter);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        init();

        //Setting Listener for Convert Button
        convert_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (spin.getSelectedItem().toString().isEmpty() || spin2.getSelectedItem().toString().isEmpty() || editText.getText().toString().isEmpty()) {
                    Toast.makeText(Currency_converter.this, "You must select both Countries and must input the amount.", Toast.LENGTH_SHORT).show();
                } else {
                    convertCurrency();
                }
            }
        });


    }

    //Initializing items for targeting views
    public void init() {
        spin = (Spinner) findViewById(R.id.spinner);
        spin2 = (Spinner) findViewById(R.id.spinner2);
        editText = (EditText) findViewById(R.id.edtext1);
        editText2 = (EditText) findViewById(R.id.editText2);
        convert_btn = (Button) findViewById(R.id.button);
        editText2.setInputType(0);
        spin.setOnItemSelectedListener(this);
        spin2.setOnItemSelectedListener(this);
        currencyUnits = new String[]{
                "Units",
                "USD",
                "NGN",
                "BRL",
                "CAD",
                "KES",
                "IDR",
                "INR",
                "JPY",
                "AED",
                "PKR"
        };

        //Creating the ArrayAdapter instance having the country list
        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, currencyUnits);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spin.setAdapter(aa);
        spin2.setAdapter(aa);
    }

    /**
     * This method convertCurrency currency values and used to set value to view
     */
    public void convertCurrency() {
        double US_Dollar = 1.22;
        double Nigerian_Naira = 445.57;
        double Brazilian_Real = 5.47;
        double Canadian_Dollar = 1.71;
        double Kenyan_Shilling = 132.53;
        double Indonesian_Rupiah = 19554.94;
        double Indian_Rupee = 95.21;
        double Japanese_YENS = 123.160;
        double UAE_Dirhams = 3.673;
        double Pakistani_Rupee = 162.74;

        double amountToChange = Double.parseDouble(editText.getText().toString());
        double amountInPounds = 0.0;
        double amountChanged = 0.0;

        //For Spinner 1
        switch (spin.getSelectedItem().toString()) {
            case "USD":amountInPounds = amountToChange / US_Dollar;break;
            case "NGN":amountInPounds = amountToChange / Nigerian_Naira;break;
            case "BRL":amountInPounds = amountToChange / Brazilian_Real;break;
            case "CAD":amountInPounds = amountToChange / Canadian_Dollar;break;
            case "KES":amountInPounds = amountToChange / Kenyan_Shilling;break;
            case "IDR":amountInPounds = amountToChange / Indonesian_Rupiah;break;
            case "INR":amountInPounds = amountToChange / Indian_Rupee;break;
            case "JPY":amountInPounds = amountToChange / Japanese_YENS;break;
            case "AED":amountInPounds = amountToChange / UAE_Dirhams;break;
            case "PKR":amountInPounds = amountToChange / Pakistani_Rupee;break;
            default:amountInPounds = 0.0;
        }

        //For Spinner 2
        switch (spin2.getSelectedItem().toString()) {
            case "USD":amountChanged = amountInPounds * US_Dollar;break;
            case "NGN":amountChanged = amountInPounds * Nigerian_Naira;break;
            case "BRL":amountChanged = amountInPounds * Brazilian_Real;break;
            case "CAD":amountChanged = amountInPounds * Canadian_Dollar;break;
            case "KES":amountChanged = amountInPounds * Kenyan_Shilling;break;
            case "IDR":amountChanged = amountInPounds * Indonesian_Rupiah;break;
            case "INR":amountChanged = amountInPounds * Indian_Rupee;break;
            case "JPY":amountChanged = amountInPounds * Japanese_YENS;break;
            case "AED":amountChanged = amountInPounds * UAE_Dirhams;break;
            case "PKR":amountChanged = amountInPounds * Pakistani_Rupee;break;
            default:amountChanged = amountInPounds * 0.0;
        }

        //Setting Converted value
        String value = String.format("%.2f", amountChanged);
        editText2.setText(value);

    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
