package com.unit.converter;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;



public class MainActivity extends AppCompatActivity {

    Button currency_btn , temp_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("Unit Converter");

        init();

    }
    public void init (){
        currency_btn = (Button) findViewById(R.id.Currency_btn);
        temp_btn = (Button) findViewById(R.id.temp_btn);

        //For Currency
        currency_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in  = new Intent(MainActivity.this,Currency_converter.class);
                startActivity(in);
            }
        });

        //For Temperature
        temp_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(MainActivity.this,Temperature_converter.class);
                startActivity(in);
            }
        });
    }

}
