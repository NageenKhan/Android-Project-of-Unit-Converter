package com.unit.converter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Temperature_converter extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Spinner spin, spin2;
    EditText editText;
    Button convert_temp;
    TextView value;
    String[] Temp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperature_converter);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        init();

        //Setting Listener for Convert Temperature
        convert_temp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (spin.getSelectedItem().toString().isEmpty() || spin2.getSelectedItem().toString().isEmpty() || editText.getText().toString().isEmpty()) {
                    Toast.makeText(Temperature_converter.this, "Required all fields", Toast.LENGTH_SHORT).show();
                } else {
                    convertTemp();
                }
            }
        });
    }
    public void init() {
        spin = (Spinner) findViewById(R.id.spinner);
        spin2 = (Spinner) findViewById(R.id.spinner2);
        editText = (EditText) findViewById(R.id.editText);
        convert_temp = (Button) findViewById(R.id.convert_temp);
        value = (TextView) findViewById(R.id.value_text);
        spin.setOnItemSelectedListener(this);
        spin2.setOnItemSelectedListener(this);
        Temp = new String[]{
                "Conversion",
                "Celsius",
                "Fahrenheit",
                "Kelvin",
        };
        //Creating the ArrayAdapter instance having the country list
        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, Temp);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spin.setAdapter(aa);
        spin2.setAdapter(aa);
    }
    private void convertTemp() {
        float cel, kel, far;
        String text = editText.getText().toString();

        //Celsius
        if (spin.getSelectedItem().equals("Celsius") && spin2.getSelectedItem().equals("Fahrenheit")) {
            cel = Float.parseFloat(text);
            far = (float) (cel * 1.8 + 32);
            value.setText("" + far);
        }

        if (spin.getSelectedItem().equals("Celsius") && spin2.getSelectedItem().equals("Kelvin")) {
            cel = Float.parseFloat(text);
            kel = (float) (cel + 273.15);
            value.setText("" + kel);
        }


        //Fahrenheit
        if (spin.getSelectedItem().equals("Fahrenheit") && spin2.getSelectedItem().equals("Celsius")) {
            far = Float.parseFloat(text);
            cel = (float) ((float)  (far - 32) *0.55);
            value.setText("" + cel);
        }


        if (spin.getSelectedItem().equals("Fahrenheit") && spin2.getSelectedItem().equals("Kelvin")){
            far = Float.parseFloat(text);
            kel = (float) ((float) (far - 32) * 0.55 + 273.15);
            value.setText("" + kel);
        }


        //Kelvin
        if(spin.getSelectedItem().equals("Kelvin") && spin2.getSelectedItem().equals("Celsius")){
            kel = Float.parseFloat(text);
           cel = (float) (kel - 273.15 );
            value.setText("" +cel);
        }

        if(spin.getSelectedItem().equals("Kelvin") && spin2.getSelectedItem().equals("Fahrenheit")){
            kel =Float.parseFloat(text);
            far = (float) ((kel -273.15) * 1.8 +32);
            value.setText(""+far);
        }

    }




    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        //do nothing
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
        //do nothing
    }
}
